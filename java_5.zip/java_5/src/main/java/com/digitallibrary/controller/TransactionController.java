package com.digitallibrary.controller;

import com.digitallibrary.dto.request.IssueBookRequest;
import com.digitallibrary.dto.response.TransactionResponse;
import com.digitallibrary.service.TransactionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * REST endpoints for book issue and return operations.
 *
 * <p>Base path: {@code /api/transactions}</p>
 * <p>The currently authenticated user's email is extracted from the
 * {@link UserDetails} principal injected by Spring Security.</p>
 */
@RestController
@RequestMapping("/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;

    /**
     * Issues a book to the authenticated member.
     * <pre>POST /api/transactions/issue</pre>
     */
    @PostMapping("/issue")
    @PreAuthorize("hasRole('MEMBER')")
    public ResponseEntity<TransactionResponse> issueBook(
            @Valid @RequestBody IssueBookRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        TransactionResponse response = transactionService.issueBook(
                userDetails.getUsername(), request.getBookId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Returns a book for the authenticated member.
     * <pre>POST /api/transactions/{transactionId}/return</pre>
     */
    @PostMapping("/{transactionId}/return")
    @PreAuthorize("hasRole('MEMBER')")
    public ResponseEntity<TransactionResponse> returnBook(
            @PathVariable UUID transactionId,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(
                transactionService.returnBook(userDetails.getUsername(), transactionId));
    }

    /**
     * Retrieves the authenticated member's transaction history.
     * <pre>GET /api/transactions/my</pre>
     */
    @GetMapping("/my")
    public ResponseEntity<Page<TransactionResponse>> getMyTransactions(
            @AuthenticationPrincipal UserDetails userDetails,
            @PageableDefault(size = 10, sort = "createdAt") Pageable pageable) {
        return ResponseEntity.ok(
                transactionService.getMyTransactions(userDetails.getUsername(), pageable));
    }

    /**
     * Admin: retrieves all transactions.
     * <pre>GET /api/transactions</pre>
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<TransactionResponse>> getAllTransactions(
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(transactionService.getAllTransactions(pageable));
    }
}
