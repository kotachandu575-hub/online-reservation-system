package com.digitallibrary.dto.response;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

/**
 * Response DTO for {@link com.digitallibrary.entity.Book}.
 */
@Getter
@Builder
public class BookResponse {
    private Long   id;
    private String isbn;
    private String title;
    private String author;
    private String category;
    private Integer totalCopies;
    private Integer availableCopies;
    private LocalDateTime createdAt;
}
