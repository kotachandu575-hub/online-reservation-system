package com.digitallibrary.service;

import com.digitallibrary.dto.response.TransactionResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

/**
 * Service contract for book issue/return transaction operations.
 */
public interface TransactionService {

    /**
     * Issues a book to the currently authenticated member.
     *
     * <p>Business rules:
     * <ul>
     *   <li>User must be ACTIVE (not suspended).</li>
     *   <li>{@code availableCopies} must be {@code > 0}.</li>
     *   <li>Member must not already have an active ISSUED loan for the same book.</li>
     *   <li>Decrements {@code availableCopies} and creates a Transaction.</li>
     *   <li>Due date is set to {@code today + 14 days}.</li>
     * </ul>
     *
     * @param userEmail email of the authenticated member
     * @param bookId    ID of the book to issue
     */
    TransactionResponse issueBook(String userEmail, Long bookId);

    /**
     * Processes a book return for the given transaction.
     *
     * <p>Business rules:
     * <ul>
     *   <li>Increments {@code availableCopies}.</li>
     *   <li>Sets {@code returnDate} and status to {@code RETURNED}.</li>
     *   <li>If past dueDate, generates a {@link com.digitallibrary.entity.Fine}.</li>
     *   <li>Fulfils the oldest pending reservation (if any).</li>
     * </ul>
     *
     * @param userEmail     email of the authenticated member
     * @param transactionId the transaction UUID to close
     */
    TransactionResponse returnBook(String userEmail, UUID transactionId);

    /** Paginated transaction history for the current member. */
    Page<TransactionResponse> getMyTransactions(String userEmail, Pageable pageable);

    /** Paginated transaction listing (admin view). */
    Page<TransactionResponse> getAllTransactions(Pageable pageable);
}
