package com.digitallibrary.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * Request body for {@code POST /api/transactions/issue}.
 */
@Getter
@Setter
public class IssueBookRequest {

    @NotNull(message = "Book ID is required")
    private Long bookId;
}
