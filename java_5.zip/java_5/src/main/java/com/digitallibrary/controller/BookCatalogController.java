package com.digitallibrary.controller;

import com.digitallibrary.dto.response.BookResponse;
import com.digitallibrary.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Public catalogue browsing endpoints — no authentication required.
 *
 * <p>Base path: {@code /api/books}</p>
 * <p>All methods are HTTP GET and are explicitly permitted in {@code SecurityConfig}.</p>
 */
@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookCatalogController {

    private final BookService bookService;

    /**
     * Paginated catalogue with optional keyword search.
     *
     * <pre>GET /api/books?keyword=java&page=0&size=10&sort=title,asc</pre>
     *
     * @param keyword optional search term matched against title, author, category
     */
    @GetMapping
    public ResponseEntity<Page<BookResponse>> getCatalogue(
            @RequestParam(required = false) String keyword,
            @PageableDefault(size = 10, sort = "title") Pageable pageable) {
        return ResponseEntity.ok(bookService.getCatalogue(keyword, pageable));
    }

    /**
     * Retrieves a single book by its ID.
     *
     * <pre>GET /api/books/{id}</pre>
     */
    @GetMapping("/{id}")
    public ResponseEntity<BookResponse> getBookById(@PathVariable Long id) {
        return ResponseEntity.ok(bookService.getBookById(id));
    }
}
