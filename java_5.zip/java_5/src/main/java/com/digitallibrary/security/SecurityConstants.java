package com.digitallibrary.security;

/**
 * Compile-time constants shared across the security layer.
 *
 * <p>Keeps magic strings in one place; runtime values (e.g., secret, expiry)
 * are read from {@code application.yml} via {@code @Value}.</p>
 */
public final class SecurityConstants {

    private SecurityConstants() {} // utility class

    /** Public endpoints that do not require a valid JWT. */
    public static final String[] PUBLIC_ENDPOINTS = {
        "/auth/**",
        "/actuator/health",
        "/actuator/info",
        "/h2-console/**"   // dev only — H2 in-memory database web UI
    };

    /** Endpoints that require ADMIN role — enforced both in SecurityFilterChain and @PreAuthorize. */
    public static final String[] ADMIN_ENDPOINTS = {
        "/admin/**"
    };
}
