package com.digitallibrary.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a suspended member attempts an action that requires ACTIVE status.
 * Maps to HTTP 403 Forbidden.
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class UserSuspendedException extends RuntimeException {

    public UserSuspendedException(String message) {
        super(message);
    }

    public UserSuspendedException() {
        super("Your account has been suspended. Please contact the library administration.");
    }
}
