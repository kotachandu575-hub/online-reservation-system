package com.digitallibrary.repository;

import com.digitallibrary.entity.Transaction;
import com.digitallibrary.enums.TransactionStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/**
 * Spring Data JPA repository for {@link Transaction} entities.
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, UUID> {

    /** All transactions for a given member (paginated). */
    Page<Transaction> findByUser_Id(UUID userId, Pageable pageable);

    /** All transactions for a specific book (paginated). */
    Page<Transaction> findByBook_Id(Long bookId, Pageable pageable);

    /**
     * Finds all {@code ISSUED} transactions whose due-date has passed.
     * Used exclusively by the nightly overdue-fine scheduler.
     */
    @Query("""
            SELECT t FROM Transaction t
            WHERE t.status = :status
              AND t.dueDate < :today
            """)
    List<Transaction> findAllByStatusAndDueDateBefore(
            @Param("status") TransactionStatus status,
            @Param("today") LocalDate today);

    /**
     * Checks whether a member currently has an active (ISSUED) loan for a book.
     * Prevents issuing the same book twice to the same member.
     */
    boolean existsByUser_IdAndBook_IdAndStatus(UUID userId, Long bookId, TransactionStatus status);

    /** All transactions by status (paginated — used for admin reporting). */
    Page<Transaction> findByStatus(TransactionStatus status, Pageable pageable);
}
