package com.digitallibrary.scheduler;

import com.digitallibrary.entity.Transaction;
import com.digitallibrary.enums.TransactionStatus;
import com.digitallibrary.repository.TransactionRepository;
import com.digitallibrary.service.impl.TransactionServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/**
 * Nightly scheduled job that identifies overdue transactions and generates
 * fine records for each one.
 *
 * <h3>Execution schedule</h3>
 * <p>Runs at midnight every day: {@code cron = "0 0 0 * * *"} (second, minute, hour,
 * day-of-month, month, day-of-week in Spring's 6-field cron format).</p>
 *
 * <h3>Idempotency</h3>
 * <p>The fine-generation logic in {@link TransactionServiceImpl#generateFineForTransaction}
 * checks whether a fine record already exists for the transaction before inserting,
 * so repeated runs (e.g., after a crash) are safe and will not create duplicate fines.</p>
 *
 * <h3>Transaction boundary</h3>
 * <p>Each fine insertion runs within its own managed transaction.
 * A failure on one fine will not roll back others.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OverdueFineScheduler {

    private final TransactionRepository  transactionRepository;
    private final TransactionServiceImpl transactionService;

    /**
     * Scans for all {@code ISSUED} transactions past their due date,
     * updates their status to {@code OVERDUE}, and generates a fine record.
     *
     * <p>Cron expression breakdown:
     * <pre>
     *  ┌──────────── second (0)
     *  │ ┌────────── minute (0)
     *  │ │ ┌──────── hour   (0 = midnight)
     *  │ │ │ ┌────── day of month (every day)
     *  │ │ │ │ ┌──── month        (every month)
     *  │ │ │ │ │ ┌── day of week  (every day)
     *  0 0 0 * * *
     * </pre>
     * </p>
     */
    @Scheduled(cron = "0 0 0 * * *")
    @Transactional
    public void processOverdueTransactions() {
        LocalDate today = LocalDate.now();
        log.info("[OverdueFineScheduler] Starting overdue check for date: {}", today);

        List<Transaction> overdueTransactions = transactionRepository
                .findAllByStatusAndDueDateBefore(TransactionStatus.ISSUED, today);

        if (overdueTransactions.isEmpty()) {
            log.info("[OverdueFineScheduler] No overdue transactions found. Exiting.");
            return;
        }

        log.info("[OverdueFineScheduler] Found {} overdue transaction(s). Processing...",
                overdueTransactions.size());

        int finesGenerated = 0;

        for (Transaction txn : overdueTransactions) {
            try {
                // 1. Mark the transaction as OVERDUE
                txn.setStatus(TransactionStatus.OVERDUE);
                transactionRepository.save(txn);

                // 2. Generate or skip fine (idempotent)
                transactionService.generateFineForTransaction(txn, today);
                finesGenerated++;

            } catch (Exception ex) {
                // Log and continue — don't fail the whole batch for one bad record
                log.error("[OverdueFineScheduler] Failed to process transaction {}: {}",
                        txn.getTransactionId(), ex.getMessage(), ex);
            }
        }

        log.info("[OverdueFineScheduler] Completed. Fines generated/updated: {}/{}",
                finesGenerated, overdueTransactions.size());
    }
}
