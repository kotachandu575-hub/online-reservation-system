package com.digitallibrary.entity;

import com.digitallibrary.enums.ReservationStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Represents a member's request to be notified when an unavailable book
 * becomes available again.
 *
 * <p>When {@code availableCopies > 0} after a return, the
 * {@code TransactionService} checks for a {@code PENDING} reservation and
 * transitions it to {@code FULFILLED}.</p>
 */
@Entity
@Table(
    name = "reservations",
    indexes = {
        @Index(name = "idx_res_user",   columnList = "user_id"),
        @Index(name = "idx_res_book",   columnList = "book_id"),
        @Index(name = "idx_res_status", columnList = "status")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reservation_id", updatable = false, nullable = false)
    private Long reservationId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false,
                foreignKey = @ForeignKey(name = "fk_res_user"))
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "book_id", nullable = false,
                foreignKey = @ForeignKey(name = "fk_res_book"))
    private Book book;

    @CreationTimestamp
    @Column(name = "request_date", updatable = false)
    private LocalDateTime requestDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private ReservationStatus status = ReservationStatus.PENDING;
}
