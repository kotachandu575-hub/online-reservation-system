package com.digitallibrary.service;

import com.digitallibrary.dto.response.UserResponse;
import com.digitallibrary.enums.AccountStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

/**
 * Service contract for user management operations.
 */
public interface UserService {

    /** Retrieves paginated list of all MEMBER-role users. Admin only. */
    Page<UserResponse> getAllMembers(Pageable pageable);

    /** Retrieves a user by their ID. */
    UserResponse getUserById(UUID id);

    /** Retrieves the currently authenticated user's profile. */
    UserResponse getCurrentUserProfile(String email);

    /** Updates the account status (ACTIVE / SUSPENDED). Admin only. */
    UserResponse updateAccountStatus(UUID id, AccountStatus status);

    /** Searches members by name. Admin only. */
    Page<UserResponse> searchMembersByName(String name, Pageable pageable);
}
