package com.digitallibrary.service;

import com.digitallibrary.dto.response.FineResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Service contract for fine management.
 */
public interface FineService {

    /** Retrieves all fines for the current user. */
    Page<FineResponse> getMyFines(String userEmail, Pageable pageable);

    /** Admin: retrieves all fines (paginated). */
    Page<FineResponse> getAllFines(Pageable pageable);

    /** Marks a fine as PAID. */
    FineResponse payFine(Long fineId, String userEmail);

    /** Returns the total outstanding (UNPAID) fine amount for a user. */
    BigDecimal getTotalUnpaidFines(UUID userId);
}
