package com.digitallibrary.repository;

import com.digitallibrary.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link Book} entities.
 */
@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    /** Used to enforce ISBN uniqueness before saving. */
    Optional<Book> findByIsbn(String isbn);

    /** ISBN uniqueness check used during book creation. */
    boolean existsByIsbn(String isbn);

    /** Paginated catalogue with optional keyword search across title, author, and category. */
    @Query("""
            SELECT b FROM Book b
            WHERE (:keyword IS NULL
                   OR LOWER(b.title)    LIKE LOWER(CONCAT('%', :keyword, '%'))
                   OR LOWER(b.author)   LIKE LOWER(CONCAT('%', :keyword, '%'))
                   OR LOWER(b.category) LIKE LOWER(CONCAT('%', :keyword, '%')))
            """)
    Page<Book> searchCatalogue(@Param("keyword") String keyword, Pageable pageable);

    /** Filter catalogue by category (paginated). */
    Page<Book> findByCategory(String category, Pageable pageable);

    /** Find only books that have at least one copy currently available. */
    Page<Book> findByAvailableCopiesGreaterThan(Integer minCopies, Pageable pageable);
}
