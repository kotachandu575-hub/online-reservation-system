package com.digitallibrary.service.impl;

import com.digitallibrary.dto.response.UserResponse;
import com.digitallibrary.entity.User;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.enums.Role;
import com.digitallibrary.exception.ResourceNotFoundException;
import com.digitallibrary.repository.UserRepository;
import com.digitallibrary.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Implementation of {@link UserService}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<UserResponse> getAllMembers(Pageable pageable) {
        return userRepository.findAllByRole(Role.MEMBER, pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(UUID id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getCurrentUserProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", email));
        return toResponse(user);
    }

    @Override
    @Transactional
    public UserResponse updateAccountStatus(UUID id, AccountStatus status) {
        User user = findOrThrow(id);
        int updated = userRepository.updateAccountStatus(id, status);
        if (updated == 0) {
            throw new ResourceNotFoundException("User", id);
        }
        user.setAccountStatus(status);
        log.info("Updated account status of user {} to {}", id, status);
        return toResponse(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserResponse> searchMembersByName(String name, Pageable pageable) {
        return userRepository.searchByName(name, pageable)
                .map(this::toResponse);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private User findOrThrow(UUID id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    private UserResponse toResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .accountStatus(user.getAccountStatus())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
