package com.digitallibrary.service;

import com.digitallibrary.dto.response.ReservationResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service contract for book reservation operations.
 */
public interface ReservationService {

    /**
     * Creates a reservation for a book with zero available copies.
     *
     * @param userEmail authenticated member's email
     * @param bookId    book to reserve
     */
    ReservationResponse reserveBook(String userEmail, Long bookId);

    /** Retrieves the current user's reservation history. */
    Page<ReservationResponse> getMyReservations(String userEmail, Pageable pageable);

    /** Admin: retrieves all reservations (paginated). */
    Page<ReservationResponse> getAllReservations(Pageable pageable);

    /** Cancels a pending reservation. */
    void cancelReservation(Long reservationId, String userEmail);
}
