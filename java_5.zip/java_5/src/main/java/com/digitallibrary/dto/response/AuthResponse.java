package com.digitallibrary.dto.response;

import com.digitallibrary.enums.Role;
import lombok.Builder;
import lombok.Getter;

/**
 * Response body for successful authentication ({@code /auth/login} and {@code /auth/register}).
 */
@Getter
@Builder
public class AuthResponse {

    /** The JWT access token to be stored by the client and sent in subsequent requests. */
    private String accessToken;

    /** Always {@code "Bearer"} — indicates the token type. */
    private String tokenType;

    private String email;
    private String name;
    private Role   role;

    /** Token expiry in milliseconds (unix epoch) for client-side countdown. */
    private long expiresAt;
}
