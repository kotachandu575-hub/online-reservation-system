package com.digitallibrary.dto.request;

import com.digitallibrary.enums.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * Request body for {@code POST /api/auth/register}.
 */
@Getter
@Setter
public class RegisterRequest {

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 150, message = "Name must be between 2 and 150 characters")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;

    /**
     * Role to assign. In production, you might want to restrict this
     * so that ADMIN accounts can only be created by existing ADMINs.
     * Defaults to MEMBER if not provided.
     */
    @NotNull(message = "Role is required")
    private Role role;
}
