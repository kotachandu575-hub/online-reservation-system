package com.digitallibrary.service.impl;

import com.digitallibrary.dto.response.TransactionResponse;
import com.digitallibrary.entity.*;
import com.digitallibrary.enums.*;
import com.digitallibrary.exception.*;
import com.digitallibrary.repository.*;
import com.digitallibrary.service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

/**
 * Core business logic for issuing and returning books.
 *
 * <p>All mutating methods are annotated with {@code @Transactional} to ensure
 * atomicity. The {@code @Version} field on {@link Book} provides optimistic
 * locking protection against concurrent checkout races.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository  transactionRepository;
    private final BookRepository         bookRepository;
    private final UserRepository         userRepository;
    private final FineRepository         fineRepository;
    private final ReservationRepository  reservationRepository;

    @Value("${application.loan.due-days:14}")
    private int dueDays;

    @Value("${application.fine.amount-per-day:5.00}")
    private BigDecimal fineAmountPerDay;

    // ─────────────────────────────────────────────────────────────────────────
    // Issue Book
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public TransactionResponse issueBook(String userEmail, Long bookId) {
        User user = findUserByEmail(userEmail);

        // Guard: account must be active
        if (user.getAccountStatus() == AccountStatus.SUSPENDED) {
            throw new UserSuspendedException();
        }

        // Guard: no duplicate active loan for same book
        if (transactionRepository.existsByUser_IdAndBook_IdAndStatus(
                user.getId(), bookId, TransactionStatus.ISSUED)) {
            throw new BookUnavailableException(
                    "You already have this book issued. Return it before issuing again.");
        }

        // Lock the book row (optimistic via @Version)
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book", bookId));

        if (book.getAvailableCopies() <= 0) {
            throw new BookUnavailableException(bookId);
        }

        // Decrement available copies — triggers @Version increment on UPDATE
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);

        LocalDate today  = LocalDate.now();
        Transaction txn  = Transaction.builder()
                .user(user)
                .book(book)
                .issueDate(today)
                .dueDate(today.plusDays(dueDays))
                .status(TransactionStatus.ISSUED)
                .build();

        Transaction saved = transactionRepository.save(txn);
        log.info("Issued book '{}' to user '{}'", book.getTitle(), user.getEmail());
        return toResponse(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Return Book
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public TransactionResponse returnBook(String userEmail, UUID transactionId) {
        Transaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", transactionId));

        // Security: members can only return their own books
        if (!txn.getUser().getEmail().equals(userEmail)) {
            throw new ResourceNotFoundException("Transaction", transactionId);
        }

        if (txn.getStatus() == TransactionStatus.RETURNED) {
            throw new IllegalStateException("This book has already been returned.");
        }

        LocalDate today  = LocalDate.now();
        txn.setReturnDate(today);
        txn.setStatus(TransactionStatus.RETURNED);

        // Increment available copies
        Book book = txn.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepository.save(book);

        // Fine logic: if returned after dueDate, create/update fine
        if (today.isAfter(txn.getDueDate())) {
            generateFineForTransaction(txn, today);
            txn.setStatus(TransactionStatus.RETURNED); // still RETURNED; fine is separate
        }

        Transaction updated = transactionRepository.save(txn);

        // Fulfil oldest pending reservation (FIFO)
        reservationRepository.findOldestPendingReservation(book.getId())
                .ifPresent(res -> {
                    res.setStatus(ReservationStatus.FULFILLED);
                    reservationRepository.save(res);
                    log.info("Fulfilled reservation {} for book '{}'",
                            res.getReservationId(), book.getTitle());
                });

        log.info("Returned book '{}' by user '{}'", book.getTitle(), userEmail);
        return toResponse(updated);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Queries
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public Page<TransactionResponse> getMyTransactions(String userEmail, Pageable pageable) {
        User user = findUserByEmail(userEmail);
        return transactionRepository.findByUser_Id(user.getId(), pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<TransactionResponse> getAllTransactions(Pageable pageable) {
        return transactionRepository.findAll(pageable).map(this::toResponse);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Fine Generation (also called by the nightly scheduler)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Creates a fine for an overdue transaction if one does not already exist.
     * Idempotent — safe to call multiple times for the same transaction.
     */
    public void generateFineForTransaction(Transaction txn, LocalDate today) {
        UUID txnId = txn.getTransactionId();
        if (fineRepository.existsByTransaction_TransactionId(txnId)) {
            log.debug("Fine already exists for transaction {}", txnId);
            return;
        }

        long overdueDays = ChronoUnit.DAYS.between(txn.getDueDate(), today);
        BigDecimal amount = fineAmountPerDay.multiply(BigDecimal.valueOf(overdueDays));

        Fine fine = Fine.builder()
                .transaction(txn)
                .userId(txn.getUser().getId())
                .amount(amount)
                .status(FineStatus.UNPAID)
                .build();

        fineRepository.save(fine);
        log.info("Generated fine of {} for transaction {} ({} overdue days)",
                amount, txnId, overdueDays);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private User findUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", email));
    }

    private TransactionResponse toResponse(Transaction t) {
        return TransactionResponse.builder()
                .transactionId(t.getTransactionId())
                .userId(t.getUser().getId())
                .userName(t.getUser().getName())
                .bookId(t.getBook().getId())
                .bookTitle(t.getBook().getTitle())
                .issueDate(t.getIssueDate())
                .dueDate(t.getDueDate())
                .returnDate(t.getReturnDate())
                .status(t.getStatus())
                .createdAt(t.getCreatedAt())
                .build();
    }
}
