package com.digitallibrary.entity;

import com.digitallibrary.enums.TransactionStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Records a single book-issue event between a {@link User} and a {@link Book}.
 *
 * <p>Lifecycle:
 * <ol>
 *   <li>Created with status {@code ISSUED} when a member checks out a book.</li>
 *   <li>Nightly cron job transitions to {@code OVERDUE} if past {@code dueDate}.</li>
 *   <li>Status becomes {@code RETURNED} when the book is brought back.</li>
 * </ol>
 * </p>
 */
@Entity
@Table(
    name = "transactions",
    indexes = {
        @Index(name = "idx_txn_user",   columnList = "user_id"),
        @Index(name = "idx_txn_book",   columnList = "book_id"),
        @Index(name = "idx_txn_status", columnList = "status")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "transaction_id", updatable = false, nullable = false)
    private UUID transactionId;

    /**
     * The member who borrowed the book.
     * EAGER fetch is acceptable here since transactions are rarely loaded in bulk.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false,
                foreignKey = @ForeignKey(name = "fk_txn_user"))
    private User user;

    /**
     * The book that was borrowed.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "book_id", nullable = false,
                foreignKey = @ForeignKey(name = "fk_txn_book"))
    private Book book;

    /** Date the book was issued. */
    @Column(name = "issue_date", nullable = false)
    private LocalDate issueDate;

    /** Date by which the book must be returned (issueDate + 14 days by default). */
    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    /** Actual return date; {@code null} until the book is returned. */
    @Column(name = "return_date")
    private LocalDate returnDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private TransactionStatus status = TransactionStatus.ISSUED;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
