package com.digitallibrary.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * Stateless JWT utility — handles token generation, parsing, and validation.
 *
 * <p>Uses HS512 (HMAC-SHA-512) for signing. The secret must be at least
 * 512 bits long; if the configured secret is too short, JJWT will throw
 * a {@code WeakKeyException} at startup — which is intentional.</p>
 *
 * <p>Token claim layout:
 * <pre>
 * {
 *   "sub": "user@example.com",
 *   "roles": "ROLE_MEMBER",
 *   "iat": 1700000000,
 *   "exp": 1700086400
 * }
 * </pre>
 * </p>
 */
@Slf4j
@Component
public class JwtUtils {

    @Value("${application.jwt.secret}")
    private String jwtSecret;

    @Value("${application.jwt.expiration-ms}")
    private long jwtExpirationMs;

    // ─────────────────────────────────────────────────────────────────────────
    // Key derivation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Derives a {@link SecretKey} from the base64-encoded secret in application.yml.
     * Called lazily on first use; the key object is not cached at the field level
     * to allow bean refresh in test contexts.
     */
    private SecretKey signingKey() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Token Generation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Generates a signed JWT from an authenticated {@link Authentication} object.
     *
     * @param authentication the fully authenticated principal returned by AuthenticationManager
     * @return compact, URL-safe JWT string
     */
    public String generateToken(Authentication authentication) {
        String roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        Date now    = new Date();
        Date expiry = new Date(now.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(authentication.getName())           // email as subject
                .claim("roles", roles)
                .issuedAt(now)
                .expiration(expiry)
                .signWith(signingKey(), Jwts.SIG.HS512)
                .compact();
    }

    /**
     * Convenience overload — generate a token for a known email + role string
     * (used internally when refreshing tokens in tests).
     */
    public String generateToken(String email, String roles) {
        Date now    = new Date();
        Date expiry = new Date(now.getTime() + jwtExpirationMs);

        return Jwts.builder()
                .subject(email)
                .claim("roles", roles)
                .issuedAt(now)
                .expiration(expiry)
                .signWith(signingKey(), Jwts.SIG.HS512)
                .compact();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Token Parsing
    // ─────────────────────────────────────────────────────────────────────────

    /** Extracts the {@code sub} (email) claim from a valid token. */
    public String getEmailFromToken(String token) {
        return parseClaims(token).getSubject();
    }

    /** Extracts the {@code roles} claim as a comma-separated string. */
    public String getRolesFromToken(String token) {
        return parseClaims(token).get("roles", String.class);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Token Validation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if the token is structurally valid, correctly signed,
     * and not yet expired.
     */
    public boolean validateToken(String token) {
        try {
            parseClaims(token); // throws on any validation failure
            return true;
        } catch (ExpiredJwtException ex) {
            log.warn("JWT expired: {}", ex.getMessage());
        } catch (UnsupportedJwtException ex) {
            log.warn("JWT unsupported: {}", ex.getMessage());
        } catch (MalformedJwtException ex) {
            log.warn("JWT malformed: {}", ex.getMessage());
        } catch (SecurityException ex) {
            log.warn("JWT signature invalid: {}", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            log.warn("JWT claims empty: {}", ex.getMessage());
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    private Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(signingKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
