package com.digitallibrary.repository;

import com.digitallibrary.entity.User;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.enums.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Spring Data JPA repository for {@link User} entities.
 */
@Repository
public interface UserRepository extends JpaRepository<User, UUID> {

    /** Lookup used by Spring Security's UserDetailsService and login flow. */
    Optional<User> findByEmail(String email);

    /** Existence check to prevent duplicate registrations. */
    boolean existsByEmail(String email);

    /** Paginated listing of all MEMBER-role accounts (for admin dashboard). */
    Page<User> findAllByRole(Role role, Pageable pageable);

    /** Paginated search by name (case-insensitive partial match). */
    @Query("SELECT u FROM User u WHERE LOWER(u.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    Page<User> searchByName(@Param("name") String name, Pageable pageable);

    /** In-place account status update — avoids fetching the full entity. */
    @Modifying
    @Query("UPDATE User u SET u.accountStatus = :status WHERE u.id = :id")
    int updateAccountStatus(@Param("id") UUID id, @Param("status") AccountStatus status);
}
