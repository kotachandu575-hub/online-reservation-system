package com.digitallibrary.service.impl;

import com.digitallibrary.dto.response.ReservationResponse;
import com.digitallibrary.entity.*;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.enums.ReservationStatus;
import com.digitallibrary.exception.*;
import com.digitallibrary.repository.*;
import com.digitallibrary.service.ReservationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of {@link ReservationService}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class ReservationServiceImpl implements ReservationService {

    private final ReservationRepository reservationRepository;
    private final BookRepository        bookRepository;
    private final UserRepository        userRepository;

    @Override
    @Transactional
    public ReservationResponse reserveBook(String userEmail, Long bookId) {
        User user = findUserByEmail(userEmail);

        if (user.getAccountStatus() == AccountStatus.SUSPENDED) {
            throw new UserSuspendedException();
        }

        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book", bookId));

        // If copies are available, the member should issue directly
        if (book.getAvailableCopies() > 0) {
            throw new BookUnavailableException(
                    "Book is available. Please issue it directly instead of reserving.");
        }

        // Prevent duplicate reservations
        if (reservationRepository.existsByUser_IdAndBook_IdAndStatus(
                user.getId(), bookId, ReservationStatus.PENDING)) {
            throw new AlreadyReservedException(bookId);
        }

        Reservation reservation = Reservation.builder()
                .user(user)
                .book(book)
                .status(ReservationStatus.PENDING)
                .build();

        Reservation saved = reservationRepository.save(reservation);
        log.info("User '{}' reserved book '{}'", userEmail, book.getTitle());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ReservationResponse> getMyReservations(String userEmail, Pageable pageable) {
        User user = findUserByEmail(userEmail);
        return reservationRepository.findByUser_Id(user.getId(), pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ReservationResponse> getAllReservations(Pageable pageable) {
        return reservationRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional
    public void cancelReservation(Long reservationId, String userEmail) {
        Reservation res = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation", reservationId));

        if (!res.getUser().getEmail().equals(userEmail)) {
            throw new ResourceNotFoundException("Reservation", reservationId);
        }

        reservationRepository.delete(res);
        log.info("Cancelled reservation {} for user '{}'", reservationId, userEmail);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private User findUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", email));
    }

    private ReservationResponse toResponse(Reservation res) {
        return ReservationResponse.builder()
                .reservationId(res.getReservationId())
                .userName(res.getUser().getName())
                .bookId(res.getBook().getId())
                .bookTitle(res.getBook().getTitle())
                .requestDate(res.getRequestDate())
                .status(res.getStatus())
                .build();
    }
}
