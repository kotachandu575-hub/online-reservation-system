package com.digitallibrary.service;

import com.digitallibrary.dto.request.BookRequest;
import com.digitallibrary.dto.response.BookResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service contract for book catalogue operations.
 */
public interface BookService {

    /** Creates a new book. Admin only. */
    BookResponse createBook(BookRequest request);

    /** Updates an existing book. Admin only. */
    BookResponse updateBook(Long id, BookRequest request);

    /** Deletes a book by ID. Admin only. */
    void deleteBook(Long id);

    /** Retrieves a single book by ID. */
    BookResponse getBookById(Long id);

    /**
     * Paginated, searchable catalogue.
     *
     * @param keyword optional search term (title, author, or category)
     * @param pageable pagination + sort parameters
     */
    Page<BookResponse> getCatalogue(String keyword, Pageable pageable);
}
