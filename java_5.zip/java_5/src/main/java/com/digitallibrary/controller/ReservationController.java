package com.digitallibrary.controller;

import com.digitallibrary.dto.request.ReservationRequest;
import com.digitallibrary.dto.response.ReservationResponse;
import com.digitallibrary.service.ReservationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * REST endpoints for book reservation management.
 *
 * <p>Base path: {@code /api/reservations}</p>
 */
@RestController
@RequestMapping("/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final ReservationService reservationService;

    /**
     * Reserves a book that has no available copies.
     * <pre>POST /api/reservations</pre>
     */
    @PostMapping
    @PreAuthorize("hasRole('MEMBER')")
    public ResponseEntity<ReservationResponse> reserveBook(
            @Valid @RequestBody ReservationRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        ReservationResponse response = reservationService.reserveBook(
                userDetails.getUsername(), request.getBookId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Retrieves the authenticated member's reservations.
     * <pre>GET /api/reservations/my</pre>
     */
    @GetMapping("/my")
    public ResponseEntity<Page<ReservationResponse>> getMyReservations(
            @AuthenticationPrincipal UserDetails userDetails,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(
                reservationService.getMyReservations(userDetails.getUsername(), pageable));
    }

    /**
     * Cancels a pending reservation owned by the authenticated member.
     * <pre>DELETE /api/reservations/{id}</pre>
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('MEMBER')")
    public ResponseEntity<Void> cancelReservation(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        reservationService.cancelReservation(id, userDetails.getUsername());
        return ResponseEntity.noContent().build();
    }

    /**
     * Admin: retrieves all reservations.
     * <pre>GET /api/reservations</pre>
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<ReservationResponse>> getAllReservations(
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(reservationService.getAllReservations(pageable));
    }
}
