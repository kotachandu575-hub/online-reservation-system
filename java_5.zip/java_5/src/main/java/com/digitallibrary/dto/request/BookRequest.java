package com.digitallibrary.dto.request;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

/**
 * Request body for creating or updating a {@link com.digitallibrary.entity.Book}.
 */
@Getter
@Setter
public class BookRequest {

    @NotBlank(message = "ISBN is required")
    @Size(max = 20, message = "ISBN cannot exceed 20 characters")
    private String isbn;

    @NotBlank(message = "Title is required")
    @Size(max = 255, message = "Title cannot exceed 255 characters")
    private String title;

    @NotBlank(message = "Author is required")
    @Size(max = 150, message = "Author name cannot exceed 150 characters")
    private String author;

    @Size(max = 100, message = "Category cannot exceed 100 characters")
    private String category;

    @NotNull(message = "Total copies is required")
    @Min(value = 1, message = "There must be at least 1 copy")
    @Max(value = 1000, message = "Cannot add more than 1000 copies at once")
    private Integer totalCopies;
}
