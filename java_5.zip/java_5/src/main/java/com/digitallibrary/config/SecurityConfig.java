package com.digitallibrary.config;

import com.digitallibrary.security.JwtAuthenticationFilter;
import com.digitallibrary.security.SecurityConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * Central Spring Security configuration.
 *
 * <h3>Key design decisions:</h3>
 * <ul>
 *   <li><b>Stateless sessions</b> — no HTTP session is ever created; authentication
 *       state lives entirely in the JWT.</li>
 *   <li><b>CSRF disabled</b> — safe for stateless REST APIs that use JWT Bearer tokens.</li>
 *   <li><b>Method security</b> — {@code @EnableMethodSecurity} activates
 *       {@code @PreAuthorize} at the service/controller level in addition to
 *       the URL-level rules below.</li>
 * </ul>
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    // ─────────────────────────────────────────────────────────────────────────
    // Security Filter Chain
    // ─────────────────────────────────────────────────────────────────────────

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // ── CSRF ────────────────────────────────────────────────────────
            .csrf(AbstractHttpConfigurer::disable)

            // ── Allow H2 console to render in an iframe (dev only) ──────────
            .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))

            // ── CORS ────────────────────────────────────────────────────────
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // ── Session management — fully stateless ────────────────────────
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // ── Authorization rules ──────────────────────────────────────────
            .authorizeHttpRequests(auth -> auth

                // Public: auth endpoints + actuator health + h2-console (dev)
                .requestMatchers(SecurityConstants.PUBLIC_ENDPOINTS).permitAll()

                // Public: read-only catalogue browsing (no login required)
                .requestMatchers(HttpMethod.GET, "/books/**").permitAll()

                // Admin-only routes — also enforced by @PreAuthorize at method level
                .requestMatchers(SecurityConstants.ADMIN_ENDPOINTS).hasRole("ADMIN")

                // Everything else requires authentication
                .anyRequest().authenticated()
            )

            // ── JWT filter ───────────────────────────────────────────────────
            // Insert our custom filter before the standard username/password filter.
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Authentication Manager
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Exposes the {@link AuthenticationManager} as a bean so it can be injected
     * into {@code AuthServiceImpl} for programmatic authentication during login.
     */
    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CORS
    // ─────────────────────────────────────────────────────────────────────────

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of("*"));   // tighten for production
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
