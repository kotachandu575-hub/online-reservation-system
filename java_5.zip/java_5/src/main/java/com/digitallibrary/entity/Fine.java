package com.digitallibrary.entity;

import com.digitallibrary.enums.FineStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents a monetary fine levied against a member for returning a book late.
 *
 * <p>A {@code Fine} has a strict {@code OneToOne} relationship with a
 * {@link Transaction}; only one fine record exists per overdue transaction.</p>
 */
@Entity
@Table(
    name = "fines",
    indexes = {
        @Index(name = "idx_fine_status",  columnList = "status"),
        @Index(name = "idx_fine_user_id", columnList = "user_id")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "fine_id", updatable = false, nullable = false)
    private Long fineId;

    /**
     * The overdue transaction that triggered this fine.
     * Mapped with {@code OneToOne}: one fine per transaction, no more.
     */
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "transaction_id", nullable = false, unique = true,
                foreignKey = @ForeignKey(name = "fk_fine_transaction"))
    private Transaction transaction;

    /**
     * Denormalised for quick lookup without joining the Transaction table.
     */
    @Column(name = "user_id", nullable = false)
    private UUID userId;

    /**
     * Calculated as: {@code overdueDays × amountPerDay} (configured in application.yml).
     * Using BigDecimal to avoid floating-point rounding issues with monetary values.
     */
    @Column(name = "amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 10)
    @Builder.Default
    private FineStatus status = FineStatus.UNPAID;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
