package com.digitallibrary.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * General application bean configuration — kept separate from
 * {@link SecurityConfig} to avoid circular dependency issues.
 *
 * <p>The {@link PasswordEncoder} bean is declared here rather than in
 * {@code SecurityConfig} because {@code CustomUserDetailsService} also
 * depends on it, and placing it in {@code SecurityConfig} would create
 * a circular dependency in the Spring context.</p>
 */
@Configuration
public class AppConfig {

    /**
     * BCrypt with strength 12 — a good balance between security and performance.
     * At strength 12, a single hash takes ~250–300 ms on modern hardware,
     * making brute-force attacks impractical.
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }
}
