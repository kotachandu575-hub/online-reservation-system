package com.digitallibrary.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Represents a book in the library catalogue.
 *
 * <h3>Optimistic Locking</h3>
 * <p>The {@link Version} field prevents concurrent checkout race conditions.
 * When two members try to issue the last copy simultaneously, Hibernate will
 * throw an {@code OptimisticLockException} for the second request, which our
 * {@code GlobalExceptionHandler} maps to HTTP 409 Conflict.</p>
 */
@Entity
@Table(
    name = "books",
    indexes = {
        @Index(name = "idx_books_isbn",   columnList = "isbn",   unique = true),
        @Index(name = "idx_books_title",  columnList = "title"),
        @Index(name = "idx_books_author", columnList = "author")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name = "isbn", nullable = false, unique = true, length = 20)
    private String isbn;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "author", nullable = false, length = 150)
    private String author;

    @Column(name = "category", length = 100)
    private String category;

    @Column(name = "total_copies", nullable = false)
    private Integer totalCopies;

    @Column(name = "available_copies", nullable = false)
    private Integer availableCopies;

    /**
     * Optimistic locking version counter — incremented automatically by Hibernate
     * on every UPDATE. Prevents lost-update anomalies during concurrent checkouts.
     */
    @Version
    @Column(name = "version", nullable = false)
    private Long version;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
