package com.digitallibrary.dto.response;

import com.digitallibrary.enums.ReservationStatus;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

/**
 * Response DTO for {@link com.digitallibrary.entity.Reservation}.
 */
@Getter
@Builder
public class ReservationResponse {
    private Long              reservationId;
    private String            userName;
    private Long              bookId;
    private String            bookTitle;
    private LocalDateTime     requestDate;
    private ReservationStatus status;
}
