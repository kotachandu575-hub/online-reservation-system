package com.digitallibrary.repository;

import com.digitallibrary.entity.Reservation;
import com.digitallibrary.enums.ReservationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Spring Data JPA repository for {@link Reservation} entities.
 */
@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    /** All reservations for a member (paginated). */
    Page<Reservation> findByUser_Id(UUID userId, Pageable pageable);

    /** All pending reservations for a specific book (paginated). */
    Page<Reservation> findByBook_IdAndStatus(Long bookId, ReservationStatus status, Pageable pageable);

    /**
     * Prevents the same member from reserving the same book twice.
     * Called before creating a new reservation.
     */
    boolean existsByUser_IdAndBook_IdAndStatus(UUID userId, Long bookId, ReservationStatus status);

    /**
     * Finds the oldest pending reservation for a book (FIFO).
     * Called by the return flow to fulfil reservations in request order.
     */
    @Query("""
            SELECT r FROM Reservation r
            WHERE r.book.id = :bookId
              AND r.status = 'PENDING'
            ORDER BY r.requestDate ASC
            LIMIT 1
            """)
    Optional<Reservation> findOldestPendingReservation(@Param("bookId") Long bookId);
}
