package com.digitallibrary.controller;

import com.digitallibrary.dto.response.FineResponse;
import com.digitallibrary.service.FineService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * REST endpoints for fine management.
 *
 * <p>Base path: {@code /api/fines}</p>
 */
@RestController
@RequestMapping("/fines")
@RequiredArgsConstructor
public class FineController {

    private final FineService fineService;

    /**
     * Retrieves the current member's fines.
     * <pre>GET /api/fines/my</pre>
     */
    @GetMapping("/my")
    public ResponseEntity<Page<FineResponse>> getMyFines(
            @AuthenticationPrincipal UserDetails userDetails,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(
                fineService.getMyFines(userDetails.getUsername(), pageable));
    }

    /**
     * Pays (marks as PAID) a specific fine owned by the authenticated member.
     * <pre>POST /api/fines/{id}/pay</pre>
     */
    @PostMapping("/{id}/pay")
    @PreAuthorize("hasRole('MEMBER')")
    public ResponseEntity<FineResponse> payFine(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(fineService.payFine(id, userDetails.getUsername()));
    }

    /**
     * Admin: retrieves all fines in the system.
     * <pre>GET /api/fines</pre>
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Page<FineResponse>> getAllFines(
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(fineService.getAllFines(pageable));
    }
}
