package com.digitallibrary.dto.response;

import com.digitallibrary.enums.FineStatus;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Response DTO for {@link com.digitallibrary.entity.Fine}.
 */
@Getter
@Builder
public class FineResponse {
    private Long          fineId;
    private UUID          transactionId;
    private UUID          userId;
    private BigDecimal    amount;
    private FineStatus    status;
    private LocalDateTime createdAt;
}
