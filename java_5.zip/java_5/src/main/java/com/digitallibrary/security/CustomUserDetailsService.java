package com.digitallibrary.security;

import com.digitallibrary.entity.User;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Spring Security {@link UserDetailsService} implementation.
 *
 * <p>Loads a {@link User} from the database by email and wraps it in a Spring
 * Security {@link UserDetails} object. This is used by the
 * {@code AuthenticationManager} during login to verify credentials.</p>
 *
 * <p>After successful login, subsequent requests use the stateless JWT filter
 * and do <strong>not</strong> call this service again.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * @throws UsernameNotFoundException if no user exists with the given email
     * @throws DisabledException         if the account is suspended
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        log.debug("Loading user by email: {}", email);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "No user found with email: " + email));

        if (user.getAccountStatus() == AccountStatus.SUSPENDED) {
            throw new DisabledException("Account suspended for: " + email);
        }

        // Prefix the role with ROLE_ as required by Spring Security
        String authority = "ROLE_" + user.getRole().name();

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPasswordHash())
                .authorities(List.of(new SimpleGrantedAuthority(authority)))
                .accountExpired(false)
                .accountLocked(user.getAccountStatus() == AccountStatus.SUSPENDED)
                .credentialsExpired(false)
                .disabled(false)
                .build();
    }
}
