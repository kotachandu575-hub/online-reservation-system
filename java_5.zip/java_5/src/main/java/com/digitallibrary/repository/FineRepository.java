package com.digitallibrary.repository;

import com.digitallibrary.entity.Fine;
import com.digitallibrary.enums.FineStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

/**
 * Spring Data JPA repository for {@link Fine} entities.
 */
@Repository
public interface FineRepository extends JpaRepository<Fine, Long> {

    /** All fines for a given user (paginated — for member's personal fine history). */
    Page<Fine> findByUserId(UUID userId, Pageable pageable);

    /** All fines by status (paginated — for admin reporting). */
    Page<Fine> findByStatus(FineStatus status, Pageable pageable);

    /**
     * Idempotency guard: checks if a fine already exists for a transaction,
     * preventing the nightly job from creating duplicate fines.
     */
    boolean existsByTransaction_TransactionId(UUID transactionId);

    /**
     * Looks up the fine tied to a specific transaction (used during return flow
     * to auto-update fine status when the member pays at the counter).
     */
    Optional<Fine> findByTransaction_TransactionId(UUID transactionId);

    /** Aggregate outstanding debt for a member — used for the fine dashboard. */
    @Query("""
            SELECT COALESCE(SUM(f.amount), 0)
            FROM Fine f
            WHERE f.userId = :userId
              AND f.status = 'UNPAID'
            """)
    BigDecimal sumUnpaidFinesByUserId(@Param("userId") UUID userId);
}
