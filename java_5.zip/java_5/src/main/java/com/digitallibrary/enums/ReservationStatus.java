package com.digitallibrary.enums;

/**
 * Tracks the state of a book reservation request.
 */
public enum ReservationStatus {
    /** Reservation has been made; waiting for a copy to become available. */
    PENDING,

    /** A copy became available and was (or is being) allocated to the member. */
    FULFILLED
}
