package com.digitallibrary.exception;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.lang.NonNull;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Centralised exception handler for the entire application.
 *
 * <p>Converts runtime exceptions into structured JSON error responses.
 * All responses share the same {@link ApiError} body shape, making it
 * easy for API consumers to parse errors consistently.</p>
 *
 * <p>Extends {@link ResponseEntityExceptionHandler} to inherit Spring MVC's
 * built-in handling for common exceptions (e.g. 405 Method Not Allowed)
 * while still allowing us to override or supplement them.</p>
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    // ─────────────────────────────────────────────────────────────────────────
    // Domain Exceptions
    // ─────────────────────────────────────────────────────────────────────────

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiError> handleResourceNotFound(
            ResourceNotFoundException ex, WebRequest request) {
        log.warn("Resource not found: {}", ex.getMessage());
        return buildError(HttpStatus.NOT_FOUND, ex.getMessage(), request);
    }

    @ExceptionHandler(BookUnavailableException.class)
    public ResponseEntity<ApiError> handleBookUnavailable(
            BookUnavailableException ex, WebRequest request) {
        log.warn("Book unavailable: {}", ex.getMessage());
        return buildError(HttpStatus.CONFLICT, ex.getMessage(), request);
    }

    @ExceptionHandler(UserSuspendedException.class)
    public ResponseEntity<ApiError> handleUserSuspended(
            UserSuspendedException ex, WebRequest request) {
        log.warn("Suspended user attempted action: {}", ex.getMessage());
        return buildError(HttpStatus.FORBIDDEN, ex.getMessage(), request);
    }

    @ExceptionHandler(DuplicateIsbnException.class)
    public ResponseEntity<ApiError> handleDuplicateIsbn(
            DuplicateIsbnException ex, WebRequest request) {
        log.warn("Duplicate ISBN: {}", ex.getMessage());
        return buildError(HttpStatus.CONFLICT, ex.getMessage(), request);
    }

    @ExceptionHandler(AlreadyReservedException.class)
    public ResponseEntity<ApiError> handleAlreadyReserved(
            AlreadyReservedException ex, WebRequest request) {
        log.warn("Duplicate reservation: {}", ex.getMessage());
        return buildError(HttpStatus.CONFLICT, ex.getMessage(), request);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Optimistic Locking (concurrent book checkout race condition)
    // ─────────────────────────────────────────────────────────────────────────

    @ExceptionHandler(OptimisticLockingFailureException.class)
    public ResponseEntity<ApiError> handleOptimisticLocking(
            OptimisticLockingFailureException ex, WebRequest request) {
        log.warn("Optimistic lock collision: {}", ex.getMessage());
        return buildError(HttpStatus.CONFLICT,
                "The book record was modified by another request. Please try again.",
                request);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Spring Security Exceptions
    // ─────────────────────────────────────────────────────────────────────────

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiError> handleBadCredentials(
            BadCredentialsException ex, WebRequest request) {
        return buildError(HttpStatus.UNAUTHORIZED, "Invalid email or password.", request);
    }

    @ExceptionHandler(DisabledException.class)
    public ResponseEntity<ApiError> handleDisabledAccount(
            DisabledException ex, WebRequest request) {
        return buildError(HttpStatus.FORBIDDEN,
                "Your account has been suspended. Contact the library administration.", request);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiError> handleAccessDenied(
            AccessDeniedException ex, WebRequest request) {
        return buildError(HttpStatus.FORBIDDEN,
                "You do not have permission to perform this action.", request);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Bean Validation Exceptions
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Handles {@code @Valid} failures on request body DTOs.
     * Returns a map of field → error-message pairs for easy client-side rendering.
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            @NonNull MethodArgumentNotValidException ex,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {

        Map<String, String> fieldErrors = new HashMap<>();
        for (FieldError err : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(err.getField(), err.getDefaultMessage());
        }

        ApiError apiError = ApiError.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.UNPROCESSABLE_ENTITY.value())
                .error("Validation Failed")
                .message("One or more fields failed validation.")
                .path(request.getDescription(false).replace("uri=", ""))
                .fieldErrors(fieldErrors)
                .build();

        log.warn("Validation failure: {}", fieldErrors);
        return ResponseEntity.unprocessableEntity().body(apiError);
    }

    /** Handles path/query param constraint violations ({@code @Min}, {@code @NotBlank}, etc.). */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiError> handleConstraintViolation(
            ConstraintViolationException ex, WebRequest request) {
        log.warn("Constraint violation: {}", ex.getMessage());
        return buildError(HttpStatus.BAD_REQUEST, ex.getMessage(), request);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Catch-all
    // ─────────────────────────────────────────────────────────────────────────

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> handleAll(Exception ex, WebRequest request) {
        log.error("Unhandled exception: {}", ex.getMessage(), ex);
        return buildError(HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred. Please contact support.", request);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helper
    // ─────────────────────────────────────────────────────────────────────────

    private ResponseEntity<ApiError> buildError(HttpStatus status, String message, WebRequest req) {
        ApiError apiError = ApiError.builder()
                .timestamp(LocalDateTime.now())
                .status(status.value())
                .error(status.getReasonPhrase())
                .message(message)
                .path(req.getDescription(false).replace("uri=", ""))
                .build();
        return ResponseEntity.status(status).body(apiError);
    }
}
