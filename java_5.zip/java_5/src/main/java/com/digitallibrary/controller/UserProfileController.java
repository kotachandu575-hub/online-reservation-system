package com.digitallibrary.controller;

import com.digitallibrary.dto.response.UserResponse;
import com.digitallibrary.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Authenticated member's own profile endpoints.
 *
 * <p>Base path: {@code /api/users}</p>
 */
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserProfileController {

    private final UserService userService;

    /**
     * Returns the profile of the currently authenticated user.
     * <pre>GET /api/users/me</pre>
     */
    @GetMapping("/me")
    public ResponseEntity<UserResponse> getMyProfile(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(
                userService.getCurrentUserProfile(userDetails.getUsername()));
    }
}
