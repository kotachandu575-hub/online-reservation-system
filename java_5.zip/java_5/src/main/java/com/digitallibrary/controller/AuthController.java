package com.digitallibrary.controller;

import com.digitallibrary.dto.request.LoginRequest;
import com.digitallibrary.dto.request.RegisterRequest;
import com.digitallibrary.dto.response.AuthResponse;
import com.digitallibrary.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Handles user registration and login.
 * These endpoints are publicly accessible (no JWT required).
 *
 * <p>Base path: {@code /api/auth}</p>
 */
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    /**
     * Registers a new user account.
     *
     * <pre>
     * POST /api/auth/register
     * Body: { "name": "...", "email": "...", "password": "...", "role": "MEMBER" }
     * </pre>
     */
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        AuthResponse response = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Authenticates an existing user and returns a JWT.
     *
     * <pre>
     * POST /api/auth/login
     * Body: { "email": "...", "password": "..." }
     * </pre>
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
