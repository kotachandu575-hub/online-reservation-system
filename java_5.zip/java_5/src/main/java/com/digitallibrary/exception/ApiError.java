package com.digitallibrary.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Uniform JSON error body returned by {@link GlobalExceptionHandler}.
 *
 * <p>The {@code fieldErrors} map is only serialised when non-null
 * (i.e., only for validation errors), keeping other error responses clean.</p>
 *
 * <pre>
 * {
 *   "timestamp": "2024-01-15T10:30:00",
 *   "status": 404,
 *   "error": "Not Found",
 *   "message": "Book not found with id: 99",
 *   "path": "/api/books/99"
 * }
 * </pre>
 */
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiError {

    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String path;

    /** Populated only for validation failures; maps field name → error message. */
    private Map<String, String> fieldErrors;
}
