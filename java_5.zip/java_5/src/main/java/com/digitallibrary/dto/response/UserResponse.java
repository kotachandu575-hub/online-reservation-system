package com.digitallibrary.dto.response;

import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.enums.Role;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Response DTO for {@link com.digitallibrary.entity.User}.
 * Never exposes the password hash.
 */
@Getter
@Builder
public class UserResponse {
    private UUID          id;
    private String        name;
    private String        email;
    private Role          role;
    private AccountStatus accountStatus;
    private LocalDateTime createdAt;
}
