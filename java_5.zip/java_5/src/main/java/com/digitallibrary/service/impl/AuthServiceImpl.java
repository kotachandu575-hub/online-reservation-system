package com.digitallibrary.service.impl;

import com.digitallibrary.dto.request.LoginRequest;
import com.digitallibrary.dto.request.RegisterRequest;
import com.digitallibrary.dto.response.AuthResponse;
import com.digitallibrary.entity.User;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.exception.DuplicateIsbnException;
import com.digitallibrary.repository.UserRepository;
import com.digitallibrary.security.JwtUtils;
import com.digitallibrary.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of {@link AuthService}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class AuthServiceImpl implements AuthService {

    private final UserRepository        userRepository;
    private final PasswordEncoder       passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils              jwtUtils;

    @Value("${application.jwt.expiration-ms}")
    private long jwtExpirationMs;

    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            // Reusing DuplicateIsbnException pattern; a generic DuplicateResourceException
            // could be added, but keeping dependencies minimal for clarity.
            throw new DuplicateIsbnException("email: " + request.getEmail() + " is already registered");
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .accountStatus(AccountStatus.ACTIVE)
                .build();

        userRepository.save(user);
        log.info("Registered new user '{}' with role {}", user.getEmail(), user.getRole());

        // Auto-login: generate a token immediately after registration
        String token = jwtUtils.generateToken(
                user.getEmail(), "ROLE_" + user.getRole().name());

        return buildAuthResponse(token, user);
    }

    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public AuthResponse login(LoginRequest request) {
        // AuthenticationManager delegates to CustomUserDetailsService + PasswordEncoder.
        // Throws BadCredentialsException / DisabledException on failure.
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(), request.getPassword()));

        String token = jwtUtils.generateToken(authentication);

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow();

        log.info("User '{}' logged in successfully", user.getEmail());
        return buildAuthResponse(token, user);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private AuthResponse buildAuthResponse(String token, User user) {
        return AuthResponse.builder()
                .accessToken(token)
                .tokenType("Bearer")
                .email(user.getEmail())
                .name(user.getName())
                .role(user.getRole())
                .expiresAt(System.currentTimeMillis() + jwtExpirationMs)
                .build();
    }
}
