package com.digitallibrary.enums;

/**
 * Tracks the lifecycle of a single book-issue transaction.
 */
public enum TransactionStatus {
    /** Book has been issued to the member and is not yet returned. */
    ISSUED,

    /** Book has been returned (on time or after a fine was applied). */
    RETURNED,

    /** Book was not returned by the due date; a fine has been or will be generated. */
    OVERDUE
}
