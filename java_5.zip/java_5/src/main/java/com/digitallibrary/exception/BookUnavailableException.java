package com.digitallibrary.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a member attempts to issue a book that has no available copies.
 * Maps to HTTP 409 Conflict.
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class BookUnavailableException extends RuntimeException {

    public BookUnavailableException(String message) {
        super(message);
    }

    public BookUnavailableException(Long bookId) {
        super("Book with ID " + bookId + " is currently unavailable for issue.");
    }
}
