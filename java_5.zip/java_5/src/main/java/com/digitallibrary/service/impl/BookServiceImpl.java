package com.digitallibrary.service.impl;

import com.digitallibrary.dto.request.BookRequest;
import com.digitallibrary.dto.response.BookResponse;
import com.digitallibrary.entity.Book;
import com.digitallibrary.exception.DuplicateIsbnException;
import com.digitallibrary.exception.ResourceNotFoundException;
import com.digitallibrary.repository.BookRepository;
import com.digitallibrary.service.BookService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of {@link BookService}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;

    @Override
    @Transactional
    public BookResponse createBook(BookRequest request) {
        if (bookRepository.existsByIsbn(request.getIsbn())) {
            throw new DuplicateIsbnException(request.getIsbn());
        }
        Book book = Book.builder()
                .isbn(request.getIsbn())
                .title(request.getTitle())
                .author(request.getAuthor())
                .category(request.getCategory())
                .totalCopies(request.getTotalCopies())
                .availableCopies(request.getTotalCopies())  // all copies available on creation
                .build();

        Book saved = bookRepository.save(book);
        log.info("Created book '{}' (ISBN: {})", saved.getTitle(), saved.getIsbn());
        return toResponse(saved);
    }

    @Override
    @Transactional
    public BookResponse updateBook(Long id, BookRequest request) {
        Book book = findOrThrow(id);

        // If ISBN is changing, ensure the new one isn't already taken
        if (!book.getIsbn().equals(request.getIsbn())
                && bookRepository.existsByIsbn(request.getIsbn())) {
            throw new DuplicateIsbnException(request.getIsbn());
        }

        int copiesDiff = request.getTotalCopies() - book.getTotalCopies();
        book.setIsbn(request.getIsbn());
        book.setTitle(request.getTitle());
        book.setAuthor(request.getAuthor());
        book.setCategory(request.getCategory());
        book.setTotalCopies(request.getTotalCopies());
        // Adjust available copies proportionally to the change in total
        book.setAvailableCopies(Math.max(0, book.getAvailableCopies() + copiesDiff));

        log.info("Updated book ID {}", id);
        return toResponse(bookRepository.save(book));
    }

    @Override
    @Transactional
    public void deleteBook(Long id) {
        Book book = findOrThrow(id);
        bookRepository.delete(book);
        log.info("Deleted book ID {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public BookResponse getBookById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BookResponse> getCatalogue(String keyword, Pageable pageable) {
        return bookRepository.searchCatalogue(keyword, pageable)
                .map(this::toResponse);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private Book findOrThrow(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book", id));
    }

    private BookResponse toResponse(Book book) {
        return BookResponse.builder()
                .id(book.getId())
                .isbn(book.getIsbn())
                .title(book.getTitle())
                .author(book.getAuthor())
                .category(book.getCategory())
                .totalCopies(book.getTotalCopies())
                .availableCopies(book.getAvailableCopies())
                .createdAt(book.getCreatedAt())
                .build();
    }
}
