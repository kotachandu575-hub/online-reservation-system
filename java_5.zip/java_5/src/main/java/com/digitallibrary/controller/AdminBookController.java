package com.digitallibrary.controller;

import com.digitallibrary.dto.request.BookRequest;
import com.digitallibrary.dto.response.BookResponse;
import com.digitallibrary.service.BookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Admin-only REST endpoints for book inventory management.
 *
 * <p>Base path: {@code /api/admin/books}</p>
 * <p>All endpoints are protected by {@code @PreAuthorize("hasRole('ADMIN')")}
 * in addition to the URL-level rule in {@code SecurityConfig}.</p>
 */
@RestController
@RequestMapping("/admin/books")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminBookController {

    private final BookService bookService;

    /**
     * Creates a new book in the catalogue.
     * <pre>POST /api/admin/books</pre>
     */
    @PostMapping
    public ResponseEntity<BookResponse> createBook(@Valid @RequestBody BookRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(bookService.createBook(request));
    }

    /**
     * Updates an existing book's details.
     * <pre>PUT /api/admin/books/{id}</pre>
     */
    @PutMapping("/{id}")
    public ResponseEntity<BookResponse> updateBook(@PathVariable Long id,
                                                   @Valid @RequestBody BookRequest request) {
        return ResponseEntity.ok(bookService.updateBook(id, request));
    }

    /**
     * Removes a book from the catalogue.
     * <pre>DELETE /api/admin/books/{id}</pre>
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }
}
