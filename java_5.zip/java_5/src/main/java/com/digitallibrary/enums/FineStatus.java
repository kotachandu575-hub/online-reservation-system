package com.digitallibrary.enums;

/**
 * Represents the payment status of a library fine.
 */
public enum FineStatus {
    /** Fine has been paid by the member. */
    PAID,

    /** Fine is outstanding and has not yet been settled. */
    UNPAID
}
