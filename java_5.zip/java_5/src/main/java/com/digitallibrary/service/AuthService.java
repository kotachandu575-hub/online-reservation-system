package com.digitallibrary.service;

import com.digitallibrary.dto.request.LoginRequest;
import com.digitallibrary.dto.request.RegisterRequest;
import com.digitallibrary.dto.response.AuthResponse;

/**
 * Contract for authentication operations.
 */
public interface AuthService {

    /**
     * Registers a new user and returns an authentication token.
     *
     * @param request registration data (name, email, password, role)
     * @return a JWT-bearing {@link AuthResponse}
     * @throws com.digitallibrary.exception.DuplicateIsbnException if email already exists
     */
    AuthResponse register(RegisterRequest request);

    /**
     * Authenticates an existing user and returns an authentication token.
     *
     * @param request login credentials (email, password)
     * @return a JWT-bearing {@link AuthResponse}
     * @throws org.springframework.security.authentication.BadCredentialsException on wrong credentials
     * @throws org.springframework.security.authentication.DisabledException         on suspended account
     */
    AuthResponse login(LoginRequest request);
}
