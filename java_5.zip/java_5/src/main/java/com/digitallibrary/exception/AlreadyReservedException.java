package com.digitallibrary.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when a member tries to create a duplicate reservation for a book
 * they have already reserved (and the reservation is still PENDING).
 * Maps to HTTP 409 Conflict.
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class AlreadyReservedException extends RuntimeException {

    public AlreadyReservedException(Long bookId) {
        super("You already have a pending reservation for book with ID: " + bookId);
    }
}
