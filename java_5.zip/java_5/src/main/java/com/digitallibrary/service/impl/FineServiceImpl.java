package com.digitallibrary.service.impl;

import com.digitallibrary.dto.response.FineResponse;
import com.digitallibrary.entity.Fine;
import com.digitallibrary.entity.User;
import com.digitallibrary.enums.FineStatus;
import com.digitallibrary.exception.ResourceNotFoundException;
import com.digitallibrary.repository.FineRepository;
import com.digitallibrary.repository.UserRepository;
import com.digitallibrary.service.FineService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Implementation of {@link FineService}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@SuppressWarnings("null")
public class FineServiceImpl implements FineService {

    private final FineRepository fineRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<FineResponse> getMyFines(String userEmail, Pageable pageable) {
        User user = findUserByEmail(userEmail);
        return fineRepository.findByUserId(user.getId(), pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<FineResponse> getAllFines(Pageable pageable) {
        return fineRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional
    public FineResponse payFine(Long fineId, String userEmail) {
        Fine fine = fineRepository.findById(fineId)
                .orElseThrow(() -> new ResourceNotFoundException("Fine", fineId));

        User user = findUserByEmail(userEmail);

        // Members can only pay their own fines; admins can pay any
        if (!fine.getUserId().equals(user.getId())) {
            throw new ResourceNotFoundException("Fine", fineId);
        }

        if (fine.getStatus() == FineStatus.PAID) {
            log.warn("Fine {} is already paid", fineId);
            return toResponse(fine);
        }

        fine.setStatus(FineStatus.PAID);
        Fine updated = fineRepository.save(fine);
        log.info("Fine {} marked as PAID by user '{}'", fineId, userEmail);
        return toResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public BigDecimal getTotalUnpaidFines(UUID userId) {
        return fineRepository.sumUnpaidFinesByUserId(userId);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private User findUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", email));
    }

    private FineResponse toResponse(Fine fine) {
        return FineResponse.builder()
                .fineId(fine.getFineId())
                .transactionId(fine.getTransaction().getTransactionId())
                .userId(fine.getUserId())
                .amount(fine.getAmount())
                .status(fine.getStatus())
                .createdAt(fine.getCreatedAt())
                .build();
    }
}
