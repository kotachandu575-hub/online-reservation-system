package com.digitallibrary.dto.response;

import com.digitallibrary.enums.TransactionStatus;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Response DTO for {@link com.digitallibrary.entity.Transaction}.
 */
@Getter
@Builder
public class TransactionResponse {
    private UUID              transactionId;
    private UUID              userId;
    private String            userName;
    private Long              bookId;
    private String            bookTitle;
    private LocalDate         issueDate;
    private LocalDate         dueDate;
    private LocalDate         returnDate;
    private TransactionStatus status;
    private LocalDateTime     createdAt;
}
