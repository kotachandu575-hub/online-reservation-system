package com.digitallibrary.enums;

/**
 * Represents the lifecycle status of a library member account.
 */
public enum AccountStatus {
    /** Account is active; the member can perform all permitted actions. */
    ACTIVE,

    /** Account has been suspended by an admin; the member cannot issue or reserve books. */
    SUSPENDED
}
