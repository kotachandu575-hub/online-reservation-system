package com.digitallibrary.enums;

/**
 * Defines the authorization roles available in the system.
 *
 * <p>Spring Security expects role names to be prefixed with {@code ROLE_}
 * when stored in the {@code GrantedAuthority} collection, but the prefix is
 * added programmatically in {@code CustomUserDetailsService} — not stored
 * in the database — so this enum stays clean.</p>
 */
public enum Role {
    /** Full administrative privileges: manage books, users, fines. */
    ADMIN,

    /** Standard library member: browse catalogue, issue/return/reserve books. */
    MEMBER
}
