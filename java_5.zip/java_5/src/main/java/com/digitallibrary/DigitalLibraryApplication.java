package com.digitallibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Entry point for the Digital Library Management System.
 *
 * <p>Key annotations:
 * <ul>
 *   <li>{@link SpringBootApplication} – enables component scan, auto-configuration,
 *       and the Spring Boot meta-annotation bundle.</li>
 *   <li>{@link EnableScheduling} – activates the {@code @Scheduled} task executor
 *       required by the nightly overdue-fine cron job (Step 7).</li>
 * </ul>
 */
@SpringBootApplication
@EnableScheduling
public class DigitalLibraryApplication {

    public static void main(String[] args) {
        SpringApplication.run(DigitalLibraryApplication.class, args);
    }
}
