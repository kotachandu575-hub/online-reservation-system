package com.digitallibrary.controller;

import com.digitallibrary.dto.response.UserResponse;
import com.digitallibrary.enums.AccountStatus;
import com.digitallibrary.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * Admin-only REST endpoints for user management.
 *
 * <p>Base path: {@code /api/admin/users}</p>
 */
@RestController
@RequestMapping("/admin/users")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminUserController {

    private final UserService userService;

    /**
     * Lists all MEMBER-role users with pagination.
     * <pre>GET /api/admin/users?page=0&size=20&sort=name,asc</pre>
     */
    @GetMapping
    public ResponseEntity<Page<UserResponse>> getAllMembers(
            @PageableDefault(size = 20, sort = "name") Pageable pageable) {
        return ResponseEntity.ok(userService.getAllMembers(pageable));
    }

    /**
     * Searches members by name (partial, case-insensitive).
     * <pre>GET /api/admin/users/search?name=john</pre>
     */
    @GetMapping("/search")
    public ResponseEntity<Page<UserResponse>> searchMembers(
            @RequestParam String name,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(userService.searchMembersByName(name, pageable));
    }

    /**
     * Retrieves a specific user's profile.
     * <pre>GET /api/admin/users/{id}</pre>
     */
    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable UUID id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    /**
     * Suspends or reinstates a user account.
     * <pre>PATCH /api/admin/users/{id}/status?status=SUSPENDED</pre>
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<UserResponse> updateAccountStatus(
            @PathVariable UUID id,
            @RequestParam AccountStatus status) {
        return ResponseEntity.ok(userService.updateAccountStatus(id, status));
    }
}
